# Balanceador-de-Carga-Round-Robin-
Objetivo: Simular el comportamiento de un load balancer que distribuye solicitudes entre varios servidores utilizando el algoritmo Round Robin.
Video: https://youtu.be/15Py8AQFSbU 
